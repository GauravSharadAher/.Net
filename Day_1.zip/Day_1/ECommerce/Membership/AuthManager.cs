﻿namespace Membership;
using CRM;
public class AuthManager
{
     public Customer cust{get;set;}
    public static void authenticate(String Email,String Password){
    bool status=false;
    if(Email=="abc@gmail.com" && Password =="iet"){
        status=true;
    }
    status=false;
    }

    public static  void NewUser(){
         Customer c = new Customer{Cid=1,Cname="Mahajan",Email="Gaurav@gmail.com",Phone_No="1234"};
         Console.WriteLine(c.Cid+" "+c.Cname);

    }

}
