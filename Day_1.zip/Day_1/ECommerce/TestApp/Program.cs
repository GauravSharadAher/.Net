﻿// See https://aka.ms/new-console-template for more information
using Catlog;
using CRM;
using Membership;
using OrderProcessing;
using ShoppingCart;

Product p = new Product{Id=1,Pname="Iphone",Quantity="10",Price=80000};
Console.WriteLine(p.Id+""+p.Pname+""+p.Quantity+""+p.Price);
AuthManager.NewUser();