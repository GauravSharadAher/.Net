﻿namespace CRM;

public class Customer
{
    public int Cid{get;set;}
    public String Cname{get;set;}
    public String Email{get;set;}
    public String Phone_No {get;set;}

}
