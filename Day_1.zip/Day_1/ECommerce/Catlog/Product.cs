﻿namespace Catlog;

public class Product
{
    public int Id {get;set;}
    public String Pname{get;set;}
    public string Quantity{get;set;}
    public float Price{get;set;}
}
