﻿using Shapes;
namespace Traingle;

public class Traingle:Shapes
{

    public Traingle():base(){}
    public Traingle():base(length,breadth,color){
        
    }

    public override void area(int length,int breadth){
        Console.WriteLine("area of triangle is",length*breadth/2);
    }
}
