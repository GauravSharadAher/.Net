﻿namespace Shapes;

public  abstract class Shapes
{
    private int color;
    private int length;
    private int breadth;

    public Shapes(){}
    public Shapes(int length,int breadth,int color){
        this.color=color;
        this.length=length;
        this.breadth=breadth;
    }

    public abstract void  area(int length,int breadth);
}
