﻿namespace Rectangle;
using Shapes;
public class Rectangle : Shapes
{

    public Rectangle():base(){}
    public Rectangle():base(length,breadth,color){

    }

    public override void area(int length int breadth){
        Console.WriteLine("area of rectangle is"+ length*breadth)
    }



}
