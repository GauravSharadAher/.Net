﻿using Shapes;
using Rectangle;
using Traingle;


Shapes  s= new Traingle(70,20);
Shapes s1 = new Rectangle(3,5);
s1.area(7,8);
s.area(3,5);
