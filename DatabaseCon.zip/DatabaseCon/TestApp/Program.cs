﻿using DAL;
using BOL;
using BLL;

string choice="";
do{
Console.WriteLine("\n\n");
Console.WriteLine("Welcome to database");
Console.WriteLine("1Show Product\n2.Insert Product\n3.Get By Id\n4.Exit");
Console.WriteLine("Choice:");
choice = Console.ReadLine();

switch(choice){
    case "1":
        List<Product> plist= DBManager.GetAllProduct();
        foreach(Product p in plist){
        Console.WriteLine(p.pid +" "+ p.pname + " " + p.qty +" " + p.price);
        }
    break;
    case "2":Console.WriteLine("Enter Product Id");
            int pid=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Product name");
            string pname=Console.ReadLine();
            Console.WriteLine("Enter Product Quantity");
            int qty=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Product price");
            float price=float.Parse(Console.ReadLine());
            Product pr =  new Product(pid,pname,qty,price);
            bool b=DBManager.Insert(pr);
            if(b){
                Console.WriteLine("Added sucessufully");
            }else{
                Console.WriteLine("Not Added");
            }
            break;
    case "3":
            Console.WriteLine("Enter Product Id");
            pid=int.Parse(Console.ReadLine());
            pr=DBManager.GetProductDetails(pid);
            Console.WriteLine(pr.pid +" "+ pr.pname + " " + pr.qty +" " + pr.price);
    break;
    case "4":
        Console.WriteLine("Thankyou visit again");
    break;
    default:
        Console.WriteLine("Invalid Input");
    break;
}
}while(choice!="4");




