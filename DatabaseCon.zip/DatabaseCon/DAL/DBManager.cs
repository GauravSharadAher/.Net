using System.Collections.Generic;
using BOL;
namespace DAL;

using MySql.Data.MySqlClient;
public  static class  DBManager{
    public static string con=@"server=192.168.10.150;port=3306;user=dac34;password=welcome;database=dac34";
    public static List<Product> GetAllProduct(){
        List<Product> plist= new List<Product>();
        MySqlConnection  connection = new MySqlConnection();
        connection.ConnectionString=con;
        string query="select * from product_s";
        try{
            MySqlCommand cmd =  new MySqlCommand();
            cmd.Connection=connection;
            connection.Open();
            cmd.CommandText=query;
            MySqlDataReader reader=cmd.ExecuteReader();
            while(reader.Read()){
                int pid=int.Parse(reader["pid"].ToString());
                string pname=reader["pname"].ToString();
                int qty=int.Parse(reader["qty"].ToString());
                float price =float.Parse(reader["price"].ToString());
                Product prod= new Product{
                        pid=pid,
                        pname=pname,
                        qty=qty,
                        price=price
                };
                plist.Add(prod);
            }

        } catch(Exception e){

        }
        finally{
            connection.Close();
        }
        return plist;
    }

     public static Product GetProductDetails(int id){
       Product prod = null;
        MySqlConnection connection = new MySqlConnection();
         connection.ConnectionString=con;
        try
        {
            string query = "SELECT * FROM product_s WHERE pid=" + id;
            connection.Open();
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                int pid = int.Parse(reader["pid"].ToString());
                string pname = reader["pname"].ToString();
                int qty = int.Parse(reader["qty"].ToString());
                 float price = float.Parse(reader["price"].ToString());
                prod = new Product
                {
                        pid=pid,
                        pname=pname,
                        qty=qty,
                        price=price
                };
            }

        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            connection.Close();
        }
        return prod;
    }

     public static bool Insert(Product prod){
        bool status=false;
        string query = "INSERT INTO product_s(pid,pname,qty,price)" +
                            "VALUES(" + prod.pid + ",'" + prod.pname + "'," + prod.qty+"," +prod.price +")";

        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = con;
        try{
            connection.Open();
            MySqlCommand command = new MySqlCommand(query, connection);
            command.ExecuteNonQuery();  //DML
            status = true;
        } 
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            connection.Close();
        }               
        return status;
     }
}


