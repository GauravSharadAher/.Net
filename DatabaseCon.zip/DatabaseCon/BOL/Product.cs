﻿namespace BOL;

public class Product
{

    public int pid{get;set;}
    public string ? pname{get;set;}
    public int qty{get;set;}
    public float price {get;set;}


    public Product(){}
    public Product(int pid,string pname,int qty,float price){
        this.pid=pid;
        this.pname=pname;
        this.qty=qty;
        this.price=price;
    }

    public String ToString(){
        return "Pid ="+ this.pid + " Pname =" +this.pname + "Qty =" + this.qty+ "price =" +this.price;
    }
}
